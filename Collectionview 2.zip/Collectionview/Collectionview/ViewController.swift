
import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource{
    
    let arr = ["1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg","1.jpeg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
  
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arr.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! custcell
        cell.img.image = UIImage(named: arr[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

